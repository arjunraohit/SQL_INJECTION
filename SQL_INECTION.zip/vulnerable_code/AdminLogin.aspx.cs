﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    public string conString = "Data Source=DESKTOP-ODORID0;Initial Catalog=Authentic;Integrated Security=True";
    protected void Button1_Click(object sender, EventArgs e)
    {
        int userCount = DataAccessLayer.GetUserByIDPwd(TextBox1.Text, TextBox2.Text);


        if (userCount >= 1)
        {
            Response.Redirect("AdminHome.aspx");
        }
        else
        {
            Label4.Text = "User Not found.";
        }
    }
}