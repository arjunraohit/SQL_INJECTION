﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class RegisterUser : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    public string conString = "Data Source=DESKTOP-ODORID0;Initial Catalog=Authentic;Integrated Security=True";
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(conString);
        con.Open();

        SqlCommand cmd = new SqlCommand("insert into user_info values(@name,@email,@password)", con);
        
        cmd.Parameters.AddWithValue("@email", txtUserId.Text.Trim());
        cmd.Parameters.AddWithValue("@name", txtName.Text.Trim());
        cmd.Parameters.AddWithValue("@password", txtPassword.Text.Trim());
        cmd.ExecuteNonQuery();
        //MessageBox.Show("Data Updated Successfully...");
        Response.Redirect("HomePage.aspx");

    }

    protected void txtID_TextChanged(object sender, EventArgs e)
    {

    }
}