﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class viewuser : System.Web.UI.Page
{
    public string conString = "Data Source=DESKTOP-ODORID0;Initial Catalog=Authentic;Integrated Security=True";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["id"] != null)
        {
            SqlConnection conn = new SqlConnection(conString);

            DataSet dset = new DataSet();
            
            using (conn)
            {
                conn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter();
                string sqlQuery = string.Format("SELECT * FROM Login WHERE Account={0}", Request.QueryString["id"]);
                SqlCommand cmd = new SqlCommand(sqlQuery, conn);
                //cmd.CommandType = CommandType.Text;
                adapter.SelectCommand = cmd;
                adapter.Fill(dset);
                if (dset.Tables[0].Rows.Count > 0)
                {
                     lblDetails.Text = dset.Tables[0].Rows[0]["Name"].ToString(); 
                    lblBalance.Text = dset.Tables[0].Rows[0]["Balance"].ToString();
                    lblAccount.Text = dset.Tables[0].Rows[0]["Account"].ToString();
                    lblEmail.Text = dset.Tables[0].Rows[0]["Email"].ToString();
                    //lblDetails.Text = Request.QueryString["id"];
                }
                
            }
        }
    }

    protected void btnWithdraw_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection(conString);
        conn.Open();
        //string sqlQuery = string.Format("update Login Set Balance = Balance+"+ TextBox1.Text+" where Account={0}", Request.QueryString["id"]);
        //SqlCommand cmd = new SqlCommand(sqlQuery, conn);
        //cmd.ExecuteScalar();

    }
}