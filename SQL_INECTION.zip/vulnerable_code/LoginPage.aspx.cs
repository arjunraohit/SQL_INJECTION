﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class LoginPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    public string conString = "Data Source=DESKTOP-ODORID0;Initial Catalog=Authentic;Integrated Security=True";
    protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
    {
        SqlConnection con = new SqlConnection(conString);
        con.Open();

        String qry = "select * from user_info where email='"+ Login1.UserName + "' and password='"+ Login1.PasswordLabelText + "'";
        //SqlCommand cmd = new SqlCommand(qry, con);
        //cmd.Parameters.AddWithValue("@email",Login1.UserName);
        //cmd.Parameters.AddWithValue("@pwd", Login1.PasswordLabelText );
        SqlDataAdapter adpt = new SqlDataAdapter(qry, con);
        DataTable dt = new DataTable();
        adpt.Fill(dt);
        if (dt.Rows.Count >= 1)
        {
            Response.Redirect("index.aspx");
        }


    }
}