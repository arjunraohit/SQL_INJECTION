﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Label3.Text = "";
    }

    public string conString = "Data Source=DESKTOP-ODORID0;Initial Catalog=Authentic;Integrated Security=True";
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(conString);
        con.Open();

        String qry = "select * from Login where Account='" + TextBox1.Text + "' and password='" + TextBox2.Text + "'";
        //SqlCommand cmd = new SqlCommand(qry, con);
        //cmd.Parameters.AddWithValue("@email",Login1.UserName);
        //cmd.Parameters.AddWithValue("@pwd", Login1.PasswordLabelText );
        SqlDataAdapter adpt = new SqlDataAdapter(qry, con);
        DataTable dt = new DataTable();
        adpt.Fill(dt);
        if (dt.Rows.Count >= 1)
        {
            Response.Redirect("viewuser.aspx?id="+TextBox1.Text);
        }
        else
        {
            Label4.Text = "User Not found.";
        }
    }
}