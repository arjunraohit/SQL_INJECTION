﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for DataAccessLayer
/// </summary>
public class DataAccessLayer
{
    public static DataSet DisplayAllUsers()
    {
        DataSet dSet = new DataSet();
        using (SqlConnection connection = ConnectionManager.GetDatabaseConnection())
        {
            try
            {
                SqlCommand command = new SqlCommand("spDisplayUserAll", connection);
                command.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter adapter = new SqlDataAdapter();
                adapter.SelectCommand = command;
                adapter.Fill(dSet);
            }
            catch (Exception ex)
            {
                throw;
            }
            return dSet;
        }
    }

    public static int GetUserByIDPwd(string userID,string pwd)
    {
        int usercount;
        using (SqlConnection connection = ConnectionManager.GetDatabaseConnection())
        {
            try
            {
                SqlCommand cmd = new SqlCommand("GetUserByIDPwd", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@userid", userID);   //for username 
                cmd.Parameters.AddWithValue("@pwd", pwd);  //for password
                usercount = (Int32)cmd.ExecuteScalar();// for taking single value

            }
            catch (Exception ex)
            {
                throw;
            }
            return usercount;
        }
    }
}