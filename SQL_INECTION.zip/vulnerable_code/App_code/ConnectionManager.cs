﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// The class is used for create a new connection
/// </summary>
public class ConnectionManager
{
    public static SqlConnection GetDatabaseConnection()
    {
        SqlConnection connection = new SqlConnection(Convert.ToString(ConfigurationManager.ConnectionStrings["MyExpConnectionString"]));
        connection.Open();

        return connection;
    }
}