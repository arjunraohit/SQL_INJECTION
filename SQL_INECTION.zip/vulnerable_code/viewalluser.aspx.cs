﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class _Default : System.Web.UI.Page
{



    public string conString = "Data Source=DESKTOP-ODORID0;Initial Catalog=Authentic;Integrated Security=True";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {            
            SqlConnection conn = new SqlConnection(conString);
            
            DataSet dset = new DataSet();
            using (conn)
            {
                conn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter();
                SqlCommand cmd = new SqlCommand("SELECT Name,Account,Email,Password,Balance FROM Login", conn);
                cmd.CommandType = CommandType.Text;
                adapter.SelectCommand = cmd;
                adapter.Fill(dset);
                gvUserInfo.DataSource = dset;
                gvUserInfo.DataBind();

            }
               
        }
    }

    protected void BtnSubmit_Click(object sender, EventArgs e)
    {
        DataSet dset = new DataSet();
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MyExpConnectionString"].ToString());
        using (conn)
        {
            conn.Open();
            SqlDataAdapter adapter = new SqlDataAdapter();
            string sqlQuery = string.Format("SELECT Name,Email,Password,Balance FROM Login WHERE Email={0}", txtUserID.Text);
            SqlCommand cmd = new SqlCommand(sqlQuery, conn);
            cmd.CommandType = CommandType.Text;
            adapter.SelectCommand = cmd;
            adapter.Fill(dset);
            gvUserInfo.DataSource = dset;
            gvUserInfo.DataBind();

        }
       
    }
}